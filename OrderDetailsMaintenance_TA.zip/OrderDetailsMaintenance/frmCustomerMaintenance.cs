
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace OrderDetailsMaintenance
{
    public partial class frmCustomerMaintenance : Form
    {
        private NorthwindContext _context;
        public Customer _customer;

        public frmCustomerMaintenance()
        {
            InitializeComponent();
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            try
            {
                _context = new NorthwindContext();
                string customerID = txtCustomerId.Text;
                

                if (string.IsNullOrWhiteSpace(customerID)) //Same as customerID == ""
                {
                    MessageBox.Show("Please enter a valid Customer ID", "Entry Error");
                    txtCustomerId.Focus();
                   
                }
                else
                {
                    _customer = _context.Customers.Find(customerID);
                    if (_customer != null)
                    {
                        txtContact.Text = _customer.ContactName;
                        txtAddress.Text = _customer.Address;
                        txtCity.Text = _customer.City;
                        txtCountry.Text = _customer.Country;

                        
                    }
                    else
                    {
                        MessageBox.Show("Customer not found", "Search Error");
                        _customer = null;
                    }

                }
            }
            catch (SqlException ex) //Make sure to include more specific Exceptions
            {
                MessageBox.Show($"An Error Occure: {ex.Message}", "System Error");

            }
            catch (Exception ex) //Make sure to include more specific Exceptions
            {
                MessageBox.Show($"An Error Occure: {ex.Message}", "System Error");

            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (_customer == null) { MessageBox.Show("Save Error"); return; }
                //Here are you are updating the Attributes of the Customers table.
                _customer.ContactName = txtContact.Text; //<-- Issues here... NullException???
                _customer.Address = txtAddress.Text;
                _customer.City = txtCity.Text;
                _customer.Country = txtCountry.Text;
                //Code to Update the DB's Customer Table in the DB
                _context.Customers.Update(_customer);
                //Saving the changes to the Northwind DB
                _context.SaveChanges();



            }
            catch (DbUpdateException ex)
            {

                MessageBox.Show($"An Error Occured: {ex.Message}", "System Error");
            }
            catch (Exception ex)
            {

                MessageBox.Show($"An Error Occured: {ex.Message}", "System Error");
            }
           
            

            

        }
    }
}